<?php
require_once("dbcontroller.php");
$db_handle = new DBController();

//$id=$_GET['id'];
$id=$_GET['fromdate'];
$id2=$_GET['todate'];
//$type=$_GET['type'];


$result= $db_handle->runQuery("SELECT AM.Code,AM.Name,(SELECT IFNULL(SUM(Amount),0) FROM general_voucher where accountmaster_Id = AM.Id and nature = 'debit' and gvdate >= '$id' and gvdate <= '$id2')  -  (SELECT IFNULL(SUM(Amount),0) FROM cash_transaction where accountmaster_Id = AM.Id and cashtype = 'cashpayment' and ctdate >= '$id' and ctdate <= '$id2') AS Debit,
(SELECT IFNULL(SUM(Amount),0) FROM general_voucher where accountmaster_Id = AM.Id and nature = 'credit' and gvdate >= '$id' and gvdate <= '$id2')  -  (SELECT IFNULL(SUM(Amount),0) FROM cash_transaction where accountmaster_Id = AM.Id and cashtype = 'cashreceived' and ctdate >= '$id' and ctdate <= '$id2') AS Credit,
SUM((SELECT IFNULL(SUM(Amount),0) FROM general_voucher where nature = 'debit' and gvdate >= '$id' and gvdate <= '$id2')  -  (SELECT IFNULL(SUM(Amount),0) FROM cash_transaction where cashtype = 'cashpayment' and ctdate >= '$id' and ctdate <= '$id2')) AS TotalDebit,
(SELECT IFNULL(SUM(Amount),0) FROM general_voucher where nature = 'credit' and gvdate >= '$id' and gvdate <= '$id2')  -  (SELECT IFNULL(SUM(Amount),0) FROM cash_transaction where cashtype = 'cashreceived' and ctdate >= '$id' and ctdate <= '$id2') AS TotalCredit


	   FROM account_master AM
	WHERE ((1 != 0) OR (((SELECT IFNULL(SUM(Amount),0) FROM general_voucher where accountmaster_Id = AM.Id and nature = 'debit' and gvdate >= '$id' and gvdate <= '$id2')  -  (SELECT IFNULL(SUM(Amount),0) FROM cash_transaction where accountmaster_Id = AM.Id and cashtype = 'cashpayment' and ctdate >= DATE_FORMAT('01-01-2016','%Y-%c-%d') and ctdate<= DATE_FORMAT('30-01-2016','%Y-%c-%d')) > 0) OR ((SELECT IFNULL(SUM(Amount),0) FROM general_voucher where accountmaster_Id = AM.Id and nature = 'credit' and gvdate >= '$id' and gvdate <= '$id2')  -  (SELECT IFNULL(SUM(Amount),0) FROM cash_transaction where accountmaster_Id = AM.Id and cashtype = 'cashreceived' and ctdate >= '$id' and ctdate <= '$id2') > 0)))	
GROUP BY AM.Id,AM.Code,AM.Name ");


///////////////////
//$header = $db_handle->runQuery("SELECT 'Transaction_Id' as TransactionId , 'Type' as cashtype,'Voucher_No' as cashcode,'Account' as ACCOUNT,'Remarks' as remarks,'Date' as trdate,'Received' as Received,'Payment' as Payment,'Open_balance' as OpeningBalance,'Close_balance' as ClosingBalance ");

$header = $db_handle->runQuery("SELECT  'Code' as cashcode,'Name' as ACCOUNT,'Debit' as remarks,'Credit' as trdate,'Total Credit' as Received,'Total debit' as Payment ");


require('../fpdf/fpdf.php');

$pdf = new FPDF();
//$pdf->SetXY(190, 290);
//$pdf->SetX(1000, 10); 

 	$pdf = new FPDF('P', 'mm', array(300,300));
    $pdf->AddPage(50);
 


$pdf->SetFont('Arial','B',12);	
$pdf->SetXY(10,5,50.50); 
$pdf->Cell(35,12,"Trial Balance",5,1,"C");
$pdf->SetXY(10,5,50.50); 
$pdf->Cell(510,12,"Jalaram Investment",5,1,"C");
$pdf->Line(10,16,290,16);
$pdf->SetFont('Arial','B',10);
$pdf->SetXY(10,14,50.50); 
$pdf->Cell(30,16,"From Date :",5,1,"C");
$pdf->SetXY(45,14,50.50);
$pdf->Cell(10,16,"$id",5,1,"C");
$pdf->SetXY(10,19,50.50); 
$pdf->Cell(25,16,"To Date :",5,1,"C");
$pdf->SetXY(45,19,50.50);
$pdf->Cell(10,16,"$id2",5,1,"C");


$pdf->SetXY(10,22,50.50); 
$pdf->Cell(280,12,"",5,1,"C");





$pdf->SetXY(10,35,50.50); 

$pdf->SetFont('Arial','B',10);		
foreach($header as $heading) 
{
	foreach($heading as $column_heading)
		$pdf->Cell(46.70,11,$column_heading,1);
}

$pdf->SetXY(10,35,50.50); 
foreach($result as $row)
 {
	$pdf->SetFont('Arial','',10);	
	$pdf->Ln();
	foreach($row as $column)
		$pdf->Cell(46.70,11,$column,1);
}
$pdf->Output('trial.pdf','D');

?>