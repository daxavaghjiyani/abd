<?php
require('pagegroup.php');
require_once("dbcontroller.php");
$db_handle = new DBController();

//$id=$_GET['id'];
//$id=$_GET['a_id'];



//$id1=date("d-m-y");

$id='29-05-2015';
$id2='11-06-2016';
$sales='1';
$status='On hold';

if($sales!='all'){
$result1 = $db_handle->runQuery("select name from users where id=$sales");
foreach($result1 as $row){
}
$user = $row['name'];
}
else
{
	$user='all';
}

$a = new DateTime($id);

$timestamp = $a->getTimestamp(); // Unix timestamp
$fromdate = $a->format('Y-m-d');

$b = new DateTime($id2);

$timestamp = $b->getTimestamp(); // Unix timestamp
$todate = $b->format('Y-m-d');
if($sales!='all' && $status!='allstatus')
{
$query="SELECT @count:=@count+1 serial_number, c.name, c.address, c.mobile, c.email, c.house_number , c.remark , c.status FROM tbl_customer c inner JOIN tbl_assign a ON c.id = a.customer_id, (SELECT @count:= 0) AS count where  a.user_id= $sales  and c.created_at >= '$fromdate' 
		AND c.created_at <= '$todate'  AND c.status='$status'";
		$result = $db_handle->runQuery("

SELECT @count:=@count+1 serial_number, c.name, c.address, c.mobile, c.email, c.house_number , c.remark , c.status FROM tbl_customer c inner JOIN tbl_assign a ON c.id = a.customer_id, (SELECT @count:= 0) AS count where  a.user_id= $sales  and c.created_at >= '$fromdate' 
		AND c.created_at <= '$todate'  AND c.status='$status'");
}
else if($sales!='all' && $status=='allstatus')
{
$query="SELECT @count:=@count+1 serial_number, c.name, c.address, c.mobile, c.email, c.house_number , c.remark , c.status FROM tbl_customer c inner JOIN tbl_assign a ON c.id = a.customer_id, (SELECT @count:= 0) AS count where  a.user_id= $sales  and c.created_at >= '$fromdate' 
		AND c.created_at <= '$todate'";
	$result = $db_handle->runQuery("

SELECT @count:=@count+1 serial_number, c.name, c.address, c.mobile, c.email, c.house_number , c.remark , c.status FROM tbl_customer c inner JOIN tbl_assign a ON c.id = a.customer_id, (SELECT @count:= 0) AS count where  a.user_id= $sales  and c.created_at >= '$fromdate' 
		AND c.created_at <= '$todate'");
}
else if($sales=='all' && $status!='allstatus')
{
$query="SELECT @count:=@count+1 serial_number, c.name, c.address, c.mobile, c.email, c.house_number , c.remark , c.status FROM tbl_customer c inner JOIN tbl_assign a ON c.id = a.customer_id, (SELECT @count:= 0) AS count where c.created_at >= '$fromdate' 
		AND c.created_at <= '$todate' AND  c.status='$status'";
	$result = $db_handle->runQuery("

SELECT @count:=@count+1 serial_number, c.name, c.address, c.mobile, c.email, c.house_number , c.remark , c.status FROM tbl_customer c inner JOIN tbl_assign a ON c.id = a.customer_id, (SELECT @count:= 0) AS count where c.created_at >= '$fromdate' 
		AND c.created_at <= '$todate' AND  c.status='$status'");
}
else
{
	$query="SELECT @count:=@count+1 serial_number, c.name, c.address, c.mobile, c.email, c.house_number , c.remark , c.status FROM tbl_customer c inner JOIN tbl_assign a ON c.id = a.customer_id, (SELECT @count:= 0) AS count where  c.created_at >= '$fromdate' 
		AND c.created_at <= '$todate'";
$result = $db_handle->runQuery("

SELECT @count:=@count+1 serial_number, c.name, c.address, c.mobile, c.email, c.house_number , c.remark , c.status FROM tbl_customer c inner JOIN tbl_assign a ON c.id = a.customer_id, (SELECT @count:= 0) AS count where  c.created_at >= '$fromdate' 
		AND c.created_at <= '$todate'");
}
$rowcount=$db_handle->numRows($query);
$header = $db_handle->runQuery("SELECT 'No' as serial_number,
	'Name' as name,'Address' as address ,'Mobno' as mobile,'Email' as email,
	'House_Number' as house_number, 'Remarks' as remark, 'Status' as status");






class PDF extends PDF_PageGroup
{
function Footer()
{
    $this->SetY(-20);
    $this->Cell(0, 6, 'Page '.$this->GroupPageNo().'/'.$this->PageGroupAlias(), 0, 0, 'C');
}
}

$pdf = new PDF();
$pdf = new PDF('P', 'mm', array(300,300));
$pdf->StartPageGroup();

$pdf->AddPage(50);

$pdf->SetFont('Arial', 'B', 12);

$pdf->SetXY(10,5,50.50); 
$pdf->Cell(510,12,"More Green Energy",5,1,"C");

//$pdf->Write(5, 'Start of group 1');
//$pdf->AddPage();

$pdf->SetFont('Arial','B',10);
$pdf->SetXY(10,14,50.50); 
$pdf->Cell(30,16,"From Date :",5,1,"C");
$pdf->SetXY(45,14,50.50);
$pdf->Cell(10,16,"$id",5,1,"C");

$pdf->SetXY(10,14,50.50); 
$pdf->Cell(470,16,"User Name :",5,1,"C");
$pdf->SetXY(10,14,50.50);
$pdf->Cell(515,16,"$user",5,1,"C");
/*
$pdf->SetXY(10,19,50.50); 
$pdf->Cell(470,16,"Grand Total :",5,1,"C");
$pdf->SetXY(10,19,50.50);
$pdf->Cell(515,16,"$Totalamount",5,1,"C");
*/


$pdf->SetXY(10,19,50.50); 
$pdf->Cell(25,16,"To Date :",5,1,"C");
$pdf->SetXY(45,19,50.50);
$pdf->Cell(10,16,"$id2",5,1,"C");


$pdf->SetXY(10,22,50.50); 
$pdf->Cell(280,12,"",5,1,"C");


$pdf->SetXY(10,35,50.50); 

$pdf->SetFont('Arial','B',10);  


$j=1;
foreach($header as $heading) 
{
	foreach($heading as $column_heading)		
{
if($j==3){
$pdf->Cell(40,15,$column_heading,1);
}
else if($j==1)
{
	$pdf->Cell(15,15,$column_heading,1);
}
else if($j==5)
{
	$pdf->Cell(47,15,$column_heading,1);
}
else if($j==6)
{
	$pdf->Cell(35,15,$column_heading,1);
}
else if($j==8)
{
	$pdf->Cell(20,15,$column_heading,1);
}

else{
$pdf->Cell(40,15,$column_heading,1);
}
$j++;
}
}

foreach($result as $row){

$pdf->SetFont('Arial','',10);	
$pdf->Ln();

$i=1;

foreach($row as $column){
	

if($i==3){
$pdf->Cell(40,15,$column,1);
}
else if($i==1)
{
	$pdf->Cell(15,15,$column,1);
}
else if($i==5)
{
	$pdf->Cell(47,15,$column,1);
}
else if($i==6)
{
	$pdf->Cell(35,15,$column,1);
}
else if($i==8)
{
	$pdf->Cell(20,15,$column,1);
}

else{
$pdf->Cell(40,15,$column,1);
}
$i++;
}
//$pdf->Write(5, 'Start of group 2');
for($k=1;$k<$rowcount;$k++)
{
$j=1;

$pdf->StartPageGroup();
$pdf->AddPage();
foreach($header as $heading) 
{
	foreach($heading as $column_heading)		
{
if($j==3){
$pdf->Cell(40,15,$column_heading,1);
}
else if($j==1)
{
	$pdf->Cell(15,15,$column_heading,1);
}
else if($j==5)
{
	$pdf->Cell(47,15,$column_heading,1);
}
else if($j==6)
{
	$pdf->Cell(35,15,$column_heading,1);
}
else if($j==8)
{
	$pdf->Cell(20,15,$column_heading,1);
}

else{
$pdf->Cell(40,15,$column_heading,1);
}
$j++;
}
}
}
}


//$pdf->AddPage();
//$pdf->AddPage();
//$pdf->AddPage();

$pdf->Output();
?>