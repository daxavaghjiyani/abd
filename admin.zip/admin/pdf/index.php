 <?php
 //echo unlink("export.pdf");
require_once("dbcontroller.php");
$db_handle = new DBController();

 if(isset($_GET['customerid']))
    {
      $id=$_GET['customerid'];
      $query = "$id";

    foreach (explode(',', $query) as $chunk)
     {
         $param = explode("=", $chunk);
          foreach($param as $i =>$key) 
          {
            $i >0;
             $sqldata=mysql_query("select `Email` from account_master where `Code`='$key'");
             $data1=mysql_fetch_array($sqldata);


              $mailSender=$data1['Email'];
             echo  "mail sended to:".$mailSender."</br>";

               $key .'</br>';






            }

    
    }


/*if(isset($_GET['fromdate'] ) && isset($_GET['todate'] ))
{

   $fromdate=$_GET['fromdate'];
      


    $todate=$_GET['todate'];

   echo  "From date :".$fromdate."</br>";
    echo  "To date :".$todate."</br>";


}

 ?>   */



 


$result = $db_handle->runQuery("select * from dhaval_jalaram");






$header = $db_handle->runQuery("SELECT 'Transaction_Id' as TransactionId , 'Type' as cashtype,'Voucher_No' as cashcode,'Account' as ACCOUNT,'Remarks' as remarks,'Date' as trdate,'Received' as Received,'Payment' as Payment,'Open_balance' as OpeningBalance,'Close_balance' as ClosingBalance");

require('../fpdf/fpdf.php');

$pdf = new FPDF();
//$pdf->SetXY(190, 290);
//$pdf->SetX(1000, 10); 
$pdf->AddPage(30);
$pdf->SetFont('Arial','B',10);		
foreach($header as $heading) 
{
	foreach($heading as $column_heading)
		$pdf->Cell(28,11,$column_heading,1);
}
foreach($result as $row)
 {
	$pdf->SetFont('Arial','',10);	
	$pdf->Ln();
	foreach($row as $column)
		$pdf->Cell(28,11,$column,1);
   $pdf->Output();

}


   
   }

?>
