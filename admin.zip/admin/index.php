<html >
<head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <title>Login | Administration Panel</title>

        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/core.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/components.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/icons.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/pages.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/responsive.css" rel="stylesheet" type="text/css" />

       

        <script src="assets/js/modernizr.min.js"></script>
        <script src="jsFile/loginJS.js"></script>

    </head>
    <body>
        <!--<div class="animationload">
            <div class="loader"></div>
        </div>-->

      
        <div class="clearfix"></div>
        <div class="wrapper-page">
        	<div class="card-box">

           

            <div class="panel-body1">
            <form class="form-horizontal m-t-20">
                <?php
                    include "shreeLib/formFields.php";
                    $dba=new formField();
                    ?>
<p><span><b>Log in</b></span> to Administrater Panel</p>
                 <div class="form-group">
                    <div class="col-xs-5 m-r-0">
                       <?php $dba->getText('uname','Username','form-control');?>
                    
</div>
               
                    <div class="col-xs-5 m-r-0">
                        <?php  $dba->getPass('pwd','Password','form-control'); ?>
                    </div>
               
                    <div class="col-xs-2">
                        <button class="btn btn-pink btn-block waves-effect waves-light" type="button" onclick="adminLogin();" id="login">Log In</button>
                    </div>
                </div>
				
                
            </form> 
           
            </div> 
    
            </div> 
                             
         
        </div>
        
  
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
      <script>
       $('#uname').keypress(function (e) {
        console.log('test');
 var key = e.which;
 if(key == 13)  // the enter key code
  {
    $('#login').click();
    return false;  
  }
});   
      
      $('#pwd').keypress(function (e) {
        console.log('test');
 var key = e.which;
 if(key == 13)  // the enter key code
  {
    $('#login').click();
    return false;  
  }
});   
      </script>
        
    	<script>
            var resizefunc = [];
        </script>

        <!-- jQuery  -->
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/detect.js"></script>
        <script src="assets/js/fastclick.js"></script>
        <script src="assets/js/jquery.slimscroll.js"></script>
        <script src="assets/js/jquery.blockUI.js"></script>
        <script src="assets/js/waves.js"></script>
        <script src="assets/js/wow.min.js"></script>
        <script src="assets/js/jquery.nicescroll.js"></script>
        <script src="assets/js/jquery.scrollTo.min.js"></script>


        <script src="assets/js/jquery.core.js"></script>
        <script src="assets/js/jquery.app.js"></script>
	
	</body>

<!-- Mirrored from coderthemes.com/ubold_1.2/dark/page-login.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 23 Dec 2015 05:43:59 GMT -->
</html>