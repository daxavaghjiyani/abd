<script>
$(window).load(function() {
  var url = window.location.href;
  
  var index = url.lastIndexOf("/") + 1;
  
  var page = url.substr(index);
  if(page=='home.php')
  {
   
    $('#home').removeClass("colorlib-active");
     $("#home").addClass("colorlib-active");
  }
  if(page=='category.php')
  {
   
    $('#category').removeClass("colorlib-active");
     $("#category").addClass("colorlib-active");
  }
  if(page=='subcategory.php')
  {
   
    $('#subcategory').removeClass("colorlib-active");
     $("#subcategory").addClass("colorlib-active");
  }
  if(page=='product.php')
  {
   
    $('#product').removeClass("colorlib-active");
     $("#product").addClass("colorlib-active");
  }
  
 });
</script>
<div class="left side-menu">
                <div class="sidebar-inner slimscrollleft">
<h3 class="profile-heading"><?php echo $_SESSION['username']; ?></h3>
<p class="profile-designation"><?php echo $_SESSION['type']; ?></p>

                    <!--- Divider -->
                    <div id="sidebar-menu">
                    
                        <ul>    
                           <?php
                            if ($_SESSION['type'] === 'Admin') {
                                             
                            ?>
                            <li id="home">
                                <a href="home.php" class="waves-effect waves-light"><i class="icon-home"></i> Home </a>
                            
                            </li>
                            <li id="category">
                                <a href="category.php" class="waves-effect waves-light"><i class="icon-note"></i> Categories </a>
                            </li>
                            <li id="subcategory">
                                <a href="subcategory.php" class="waves-effect waves-light"><i class="icon-note"></i> Sub categories </a>
                            </li>
                            <li id="product">
                                <a href="product.php" class="waves-effect waves-light"><i class="icon-note"></i> Products </a>
                            </li>

                        
                            <?php
                                  }
                                ?>
                              
                         
                        </ul>
                        <div class="clearfix"></div>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>