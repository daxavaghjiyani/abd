<?php
$db_user="tssadmin1";
$db_password="tssadmin@123";
$db_host="localhost";
$db_name="tssadmin1";
$link=  mysql_connect($db_host,$db_user,$db_password);
$db_result=  mysql_select_db($db_name,$link);
if(!$db_result){
    echo 'can not connect to database '.  mysql_error();
}
 else {

}
?>