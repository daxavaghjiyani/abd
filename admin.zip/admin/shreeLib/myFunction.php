<?php

class myFunction {

    //put your code here
    public $gHead = array("Sale", "Purchase", "Sundry Debtors", "Sundry Creditors", "Bank Current A/C", "Cash", "Capital", "Stock");
    protected $dba = null;

    function  GetDatabase() {
        include 'DB_Adapter.php';
        $this->dba = new DB_Adapter();
    }

    function GetCompany() {
        $this->GetDatabase();
        $com = array();
        $data = $this->dba->getRow("company_details", array("company_name"), "1");
        $i = 0;
        foreach ($data as $val) {
            $com[$i] = $val[0];
            $i++;
        }
        return $com;
    }

    function cashOut($cash){
        $dba=new DB_Adapter();
        $old_cash=$dba->getRow("party_details", array("p_balance"), "id=16");
        $new_cash=$old_cash[0][0] - $cash;
        $field=array("p_balance"=>$new_cash);
        $result=$dba->updateRow("party_details",$field,"id=16");
    }

    function cashIn($cash){
        $dba=new DB_Adapter();
        $old_cash=$dba->getRow("party_details", array("p_balance"), "id=16");
        $new_cash=$old_cash[0][0] + $cash;
        $field=array("p_balance"=>$new_cash);
        $result=$dba->updateRow("party_details",$field,"id=16");
    }

    function bankOut($cash){
        $dba=new DB_Adapter();
        $old_cash=$dba->getRow("party_details", array("p_balance"), "id=17");
        $new_cash=$old_cash[0][0] - $cash;
        $field=array("p_balance"=>$new_cash);
        $result=$dba->updateRow("party_details",$field,"id=17");
    }

    function bankIn($cash){
        $dba=new DB_Adapter();
        $old_cash=$dba->getRow("party_details", array("p_balance"), "id=17");
        $new_cash=$old_cash[0][0] + $cash;
        $field=array("p_balance"=>$new_cash);
        $result=$dba->updateRow("party_details",$field,"id=17");
    }

}

?>
