<?php
ob_start();
session_start();
unset($_SESSION['user_user_name'], $_SESSION['user_type']);
session_destroy();
header("Location:../login.php");
?>