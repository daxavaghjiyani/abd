<?php
  include 'validation.php';
class formField{
    function getText($name,$place,$class){
        echo '<input type="text" name="'.$name.'" id="'.$name.'" class="'.$class.'" onkeypress="return textval(event)" placeholder="'.$place.'" required>';
    }
    function getNumber($name,$place,$class){
        echo '<input type="text" name="'.$name.'" id="'.$name.'" class="'.$class.'"  onkeypress="return numval(event)" placeholder="'.$place.'" required>';
    }
    function getNormal($name, $place,$class){
        echo '<input type="text" name="'.$name.'" id="'.$name.'" class="'.$class.'" placeholder="'.$place.'" required>';
    }    
	function getPass($name, $place,$class){
        echo '<input type="password" name="'.$name.'" id="'.$name.'" class="'.$class.'" placeholder="'.$place.'" required>';
    } 
    function  getEmail($name, $place,$class){
        echo '<input type="text" name="'.$name.'" id="'.$name.'" class="'.$class.'" onblur="chkemail(this.id)" placeholder="'.$place.'" required>';
    }
    function getSelect($name,$value,$class){
        echo '<select name="'.$name.'" id="'.$name.'" class="'.$class.'" required>';
        echo '<option value="">Select</option>';
        foreach ($value as $item) {
            echo '<option value="'.$item.'">'.$item.'</option>';
        }
        echo '</select>';
    }
    function getButton($name,$value,$class){
        echo '<input type="submit" name="'.$name.'" class="'.$class.'" id="'.$name.'" value="'.$value.'">';
    }

}
?>
