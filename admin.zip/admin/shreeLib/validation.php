<script type="text/javascript">
  function textval(e) {
    var unicode = e.charCode ? e.charCode : e.keyCode
      if (unicode != 8) { //if the key isn't the backspace key (which we should allow)
        if ((unicode < 65 || unicode > 90) && (unicode < 97 || unicode > 122) && unicode != 32 && unicode != 9) //if not a number
        return false //disable key press
    }

  }
  function numval(e) {
    var unicode = e.charCode ? e.charCode : e.keyCode
      if (unicode != 8) { //if the key isn't the backspace key (which we should allow)
        if ((unicode < 48 || unicode > 57) && unicode != 9) //if not a number
        return false //disable key press
    }
  }
  function chkemail(email) {
    var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    var email = document.getElementById(email);
        var emval = email.value;
        if (emval.length > 0) {
          if (!emval.match(filter)) {
        alert("Enter Valid Email");
        email.value = "";
        email.style.backgroundColor = "rgba(255,0,0.6)";
        var tmt = setTimeout(function() {
                  document.getElementById('email').focus();
                }, 1);
        return false;
      }
    }

    return true;
  }

</script>