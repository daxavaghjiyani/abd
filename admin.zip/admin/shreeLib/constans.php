<?php

//Set All Status Here Globely===============================
define("Client", "Client"); //User type as client
define("Transporter", "Transporter"); // User type as tranporter
define("Active", "Active"); // user status as active
define("Deactive", "Deactive"); // usr status as deactive
define("YESUSER", "YES"); //status that admin will approved message/Question for user
define("NOUSER", "NO"); //status that admin not yet approved message/Question for user
define("ANSWARE", "ANS"); //status that User/Admin has answared/replay of question/message
//========================================================
?>
