<?php
require '../PDF/fpdf.php';
class PDF extends FPDF
{
// Load data
function Header()
{
    // Logo
    // Arial bold 15
    $this->SetFont('Arial','B',15);
    // Move to the right
    $this->Cell(80);
    // Title
    $this->Cell(30,10,'J H JADEJA & SONS',0,0,'C');
    $this->Ln(6);
    $this->Cell(55);
    $this->Cell(80,10,'VODAFONE SUPER DISTRIBUTOR',0,0,'C');
    // Line break
    $this->Ln(10);
}

// Page footer
function Footer()
{
    // Position at 1.5 cm from bottom
    $this->SetY(-15);
    // Arial italic 8
    $this->SetFont('Arial','I',8);
    // Page number
    $this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
}
    function LoadData($file)
{
    // Read file lines
   // $lines = file($file);
    $data = array();
    //foreach($lines as $line)
      //  $data[] = explode(';',trim($line));
    return $data;
}

// Better table
function ImprovedTable($header, $data)
{
    // Column widths
    $w = array(20, 30, 20, 40,50);
    // Header
    for($i=0;$i<count($header);$i++)
        $this->Cell($w[$i],7,$header[$i],1);
    $this->Ln();
    // Data
    foreach($data as $row)
    {
        $this->Cell($w[0],6,$row[0],1);
        $this->Cell($w[1],6,$row[1],1);
        $this->Cell($w[2],6,$row[2],1);
        $this->Cell($w[3],6,$row[3],1);
        $this->Cell($w[4],6," ",1);
        $this->Ln();
    }
    // Closing line
    //$this->Cell(array_sum($w),0,'','T');
}

// Colored table
function FancyTable($header, $data)
{
    // Colors, line width and bold font
    $this->SetFillColor(255,0,0);
    $this->SetTextColor(255);
    $this->SetDrawColor(128,0,0);
    $this->SetLineWidth(.3);
    $this->SetFont('','B');
    // Header
    $w = array(40, 35, 40, 45);
    for($i=0;$i<count($header);$i++)
        $this->Cell($w[$i],7,$header[$i],1,0,'C',true);
    $this->Ln();
    // Color and font restoration
    $this->SetFillColor(224,235,255);
    $this->SetTextColor(0);
    $this->SetFont('');
    // Data
    $fill = false;
    foreach($data as $row)
    {
        $this->Cell($w[0],6,$row[0],'LR',0,'L',$fill);
        $this->Cell($w[1],6,$row[1],'LR',0,'L',$fill);
        $this->Cell($w[2],6,number_format($row[2]),'LR',0,'R',$fill);
        $this->Cell($w[3],6,number_format($row[3]),'LR',0,'R',$fill);
        $this->Ln();
        $fill = !$fill;
    }
    // Closing line
    $this->Cell(array_sum($w),0,'','T');
}
}


include '../PHP_Class/DB_Adapter.php';
$DBA=new DB_Adapter();
$field=array("v_srno,","v_mobile,","v_cifno,","v_cusname,","v_refname");
$data=$DBA->getRow("vodafone_form", $field, "1");

$pdf = new PDF();
// Column headings
$header = array("SR No","Mobile No","CIF No","Full Name","Rejection Reason");
$pdf->SetFont('Arial','',14);
$pdf->AddPage();
$pdf->Cell(50, 6, "Date: ".  date("d-m-Y"),1);
$pdf->Cell(70, 6, "Naliya",1,0,"C");
$pdf->Cell(40, 6, "Lot No. 2",1);
$pdf->Ln();
$pdf->SetFont('Arial','',12);
$pdf->ImprovedTable($header,$data);
$pdf->Ln(5);
$wd=60;
$wd2=25;
$pdf->Cell($wd,6,"Accepted",1);
$pdf->Cell($wd2,6,"10",1);
$pdf->Ln();

$pdf->Cell($wd,6,"Rejected",1);
$pdf->Cell($wd2,6,"10",1);
$pdf->Ln();

$pdf->Cell($wd,6,"Total Pickup",1);
$pdf->Cell($wd2,6,"10",1);
$pdf->Ln();

$pdf->Cell($wd,6,"Runner In Time",1);
$pdf->Cell($wd2,6,"10",1);
$pdf->Ln();

$pdf->Cell($wd,6,"Runner Out Time",1);
$pdf->Cell($wd2,6,"10",1);
$pdf->Ln();

$pdf->Cell($wd,6,"Runner Reaching Time",1);
$pdf->Cell($wd2,6,"10",1);

$pdf->Output("Test.pdf",'D');
?>