import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.Charset;
import java.net.URLEncoder;
import java.io.DataOutputStream;

public class sms {
	public static void main(String[] args) {
		try {
			URL obj = new URL("https://www.5centsms.com.au/api/v4/sms/123345");
			HttpURLConnection con = (HttpURLConnection) obj.openConnection();

			con.setRequestMethod("DELETE");

			con.setRequestProperty("User", "[Your Username (Email)]");
			con.setRequestProperty("Api-Key", "[Your API Key]");

			BufferedReader in = new BufferedReader(
				new InputStreamReader(con.getInputStream()));

			String inputLine;
			StringBuffer response = new StringBuffer();

			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}

			in.close();

			System.out.println(response.toString());

		} catch (Exception e) {
			System.out.println(e.toString());
		}
	}
}
