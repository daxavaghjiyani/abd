<?php
	$url = 'https://www.5centsms.com.au/api/v4/recharge';

	$fields = array(
		'amount' => urlencode('10000'),

	);
	$fields_string = "";
	foreach($fields as $key => $value) {
		$fields_string .= $key . '=' . $value . '&';
	}
	rtrim($fields_string, '&');

	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $fields_string);

	curl_setopt($ch, CURLOPT_HTTPHEADER, array(
		'User: [Your Username (Email)]',
		'Api-Key: [Your API Key]',
	));

	$result = curl_exec($ch);
	curl_close($ch);

	$response = json_decode($result, true);
	print_r($response);
?>
