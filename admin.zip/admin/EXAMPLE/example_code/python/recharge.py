import requests
import certifi
import json

header_data = {
	'User': '[Your Username (Email)]',
	'Api-Key': '[Your API Key]'
}

post_data = {
	'amount': '10000',
}

r = requests.post(
	"https://www.5centsms.com.au/api/v4/recharge",
	data = post_data,
	headers = header_data
)

response = json.loads(r.content)
print response
