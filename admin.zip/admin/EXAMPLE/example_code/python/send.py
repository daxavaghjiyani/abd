import requests
import certifi
import json

header_data = {
	'User': '[Your Username (Email)]',
	'Api-Key': '[Your API Key]'
}

post_data = {
	'sender': '0403123123',
	'to': '0403111111',
	'message': 'Test Message',
	'test': 'true',
}

r = requests.post(
	"https://www.5centsms.com.au/api/v4/sms",
	data = post_data,
	headers = header_data
)

response = json.loads(r.content)
print response
