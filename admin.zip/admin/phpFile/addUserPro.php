<?php
include "../shreeLib/DBAdapter.php";
$dba=new DBAdapter();
$response;
$_POST['password']=md5($_POST['password']);
$data=$dba->getRow("users",array('*'),"email='".$_POST['email']."' and name='".$_POST['name']."'");
if($data != null)
{
	$response=array("status"=>false,"msg"=>"Users Not Added Successfully");
}
else
{
	
	if($dba->setData("users",array('name' => $_POST['name'],'email' => $_POST['email'],'mobile' => $_POST['mobile'],'password' => $_POST['password'],'type' => $_POST['type'],'created_at' => date('Y-m-d'),'created_at_user_id' => $_POST['created_at_user_id']))){
	$data=$dba->getRow("users",array('name' => $_POST['name'],'email' => $_POST['email'],'mobile' => $_POST['mobile'],'password' => $_POST['password'],'type' => $_POST['type'],'created_at' => date('Y-m-d'),'created_at_user_id' => $_POST['created_at_user_id']),"1");
	$response=array("status"=>true,"msg"=>"Users Added Successfully","data"=>$data);
	}else{
	$response=array("status"=>false,"msg"=>"Users Not Added Successfully");
	}
}
echo json_encode($response);


?>