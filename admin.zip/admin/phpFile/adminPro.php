<?php
include '../shreeLib/dbconn.php';
$response;
if($_POST)
{
    $uname= $_POST['username'];
    $pwd=$_POST['password'];
	$uname = stripslashes($uname);
	$pwd = stripslashes($pwd);
	$uname = mysqli_real_escape_string($con,$uname);
	$pwd = mysqli_real_escape_string($con,$pwd);
	$en_pass=md5($pwd);
	$en_pass= mysqli_real_escape_string($con,$en_pass);
    $qry = "SELECT id, name, password, type, email FROM users WHERE name='$uname' AND password='$en_pass'";
    $res = mysqli_query($con,$qry);
    $num_row = mysqli_num_rows($res);
    $row=mysqli_fetch_assoc($res);
    if( $num_row == 1 ) {
            $response = array("status" => true, "msg" => "Login  Successfully");
            session_start();
            $_SESSION['id'] = $row['id'];
            $_SESSION['username'] = $row['name'];
			$_SESSION['type'] = $row['type'];
            $_SESSION['email'] = $row['email'];

    }
	else
	{
		 $response = array("status" => false, "msg" => "Login  failed");
	}
    echo json_encode($response);
}
?>