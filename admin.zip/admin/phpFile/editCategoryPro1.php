<?php

include "../shreeLib/DBAdapter.php";
$dba = new DBAdapter();
$response;
if ($_POST) {
    if ($dba->updateRow("tbl_employee", array('name' => $_POST['name'],'address' => $_POST['address'],'email' => $_POST['email'],'mobile' => $_POST['mobile'],'designation' => $_POST['designation'],'salary' => $_POST['salary'],'account_no' => $_POST['account_no'],'ifsc_code' => $_POST['ifsc_code'],'employee_status' => $_POST['employee_status']), "id =" . $_POST['id'])) {
        $data = $dba->getRow("tbl_employee", array('*'), "id =" . $_POST['id']);
        $response = array("status" => true, "msg" => "Employee Updated Successfully", "data" => $data);
    } else {
        $response = array("status" => false, "msg" => "Employee Not Updated Successfully");
    }
    echo json_encode($response);
}
?>