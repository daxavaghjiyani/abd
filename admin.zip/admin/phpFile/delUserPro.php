<?php

include "../shreeLib/DBAdapter.php";
$dba = new DBAdapter();
$response;
if ($_POST) {
	if($data=$dba->delRow("id =" .$_POST['id'],"users"))
	{
         $data = $dba->getRow("users", array("*"), "1");
        $response = array("status" => true, "msg" => "Row deleted Successfully", "data" => $data);
    } 
	else 
	{
        $response = array("status" => false, "msg" => "Row Not deleted");
    }
    echo json_encode($response);
}
?>