<?php
	include "shreeLib/dbconn.php";
	
	$q=$_GET['name']; 

 
 $my_data=mysql_real_escape_string($q);

 
 $sql="SELECT id, email, address, mobile from tbl_customer where name = '$my_data'";

 $result = mysqli_query($con,$sql);

 if($result)
 {
  while($row=mysqli_fetch_assoc($result)){
  $arr['id']=$row['id'];
	  $arr['email']=$row['email'];
	  $arr['mobile']=$row['mobile'];
	  $arr['address']=$row['address'];
  }

}
echo json_encode($arr);

?>