<?php

include "../shreeLib/DBAdapter.php";
$dba = new DBAdapter();
$response;
if ($_POST) {
	$_POST['password'] = md5($_POST['password']);
    if ($dba->updateRow("users", array('name' => $_POST['name'],'email' => $_POST['email'],'mobile' => $_POST['mobile'],'password' => $_POST['password'],'type' => $_POST['type'],'updated_at' => date('Y-m-d'),'updated_user_id' => $_POST['updated_user_id']), "id =" . $_POST['id'])) {
        $data = $dba->getRow("users", array('*'), "id =" . $_POST['id']);
        $response = array("status" => true, "msg" => "User Updated Successfully", "data" => $data);
    } else {
        $response = array("status" => false, "msg" => "User Not Updated Successfully");
    }
    echo json_encode($response);
}
?>