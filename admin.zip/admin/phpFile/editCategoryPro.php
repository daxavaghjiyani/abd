<?php

include "../shreeLib/DBAdapter.php";
$dba = new DBAdapter();
$response;
if ($_POST) {

    if ($dba->updateRow("tbl_customer", array('name' => $_POST['name'],'address' => $_POST['address'],'add_info' => $_POST['add_info'],'state' => $_POST['state'],'project' => $_POST['project'],'project_status' => $_POST['project_status'],'email' => $_POST['email'],'mobile' => $_POST['mobile'],'house_number' => $_POST['house'],'admin_created_date' => date("Y-m-d H:i:S"),'updated_at' => date('Y-m-d'),'updated_user_id' => $_POST['updated_user_id']), "id =" . $_POST['id'])) {
        $data = $dba->getRow("tbl_customer", array('*'), "id =" . $_POST['id']);
        $response = array("status" => true, "msg" => "Customer Updated Successfully", "data" => $data);
    } else {
        $response = array("status" => false, "msg" => "Customer Not Updated Successfully");
    }
    echo json_encode($response);
}
?>