<?php
	include "../shreeLib/dbconn.php";
	
	$q=$_POST['id']; 
$sql="SELECT * from category";
//echo $sql;
 $result = mysqli_query($con,$sql);

 ?>

 <label for="field-1" class="control-label">Select Parent Category If You Want to Change</label>
<select name="editcategory[]" multiple class="form-control"  id="editcategory" >

                                

 <?php

  while($row=mysqli_fetch_array($result)){
  
?>
  <option value="<?php echo $row['id']; ?>" ><?php echo $row['name']; ?></option>
<?php 

  }


?>
</select> 
<script type="text/javascript">
            jQuery(document).ready(function($) {
               

                $('select').selectpicker();
                $('select[name=editcategory]').selectpicker('val', 1);
            });
        </script>