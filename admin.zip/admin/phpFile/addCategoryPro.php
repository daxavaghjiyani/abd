<?php
include "../shreeLib/DBAdapter.php";
$dba=new DBAdapter();
$response;
if($dba->setData("tbl_customer",array('name' => $_POST['name'],'address' => $_POST['address'],'add_info' => $_POST['add_info'],'state' => $_POST['state'],'project' => $_POST['project'],'project_status' => $_POST['project_status'],'email' => $_POST['email'],'mobile' => $_POST['mobile'],'house_number' => $_POST['house'],'admin_created_date' => date("Y-m-d H:i:s"),'created_at' => date('Y-m-d'),'created_at_user_id' => $_POST['created_at_user_id']))){
$data=$dba->getRow("tbl_customer",array('name' => $_POST['name'],'address' => $_POST['address'],'add_info' => $_POST['add_info'],'email' => $_POST['email'],'mobile' => $_POST['mobile'],'house_number' => $_POST['house'],'admin_created_date' => date("Y-m-d H:i:s"),'created_at' => date('Y-m-d'),'created_at_user_id' => $_POST['created_at_user_id']),"1");
$response=array("status"=>true,"msg"=>"Customer Added Successfully","data"=>$data);
}else{
$response=array("status"=>false,"msg"=>"Customer Not Added Successfully");
}
echo json_encode($response);


?>