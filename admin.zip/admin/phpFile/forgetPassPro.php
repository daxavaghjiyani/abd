<?php
include "../shreeLib/dbconn.php";
if(isset($_POST['change']))
{
	$new = $_POST['new'];
	$en_pass=md5($new);
	$en_pass = stripslashes($en_pass);
	$en_pass= mysqli_real_escape_string($con,$en_pass);
	$sql="update users set password='".$en_pass."' where id=".$_POST['change'];
	if($result=mysqli_query($con,$sql))
		echo '1';
		else
		echo '0';
}
?>