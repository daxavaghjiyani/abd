<?php


$url = 'https://www.5centsms.com.au/api/v4/sms'; 

	$fields = array(
		'sender' => urlencode('61429393415'), 
		'to' => urlencode('61488135298'), 
		'message' => urlencode('testmessage'), 

	);
	$fields_string = "";
	foreach($fields as $key => $value) { 
		$fields_string .= $key . '=' . $value . '&';
	}
	rtrim($fields_string, '&');

	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $fields_string);

	curl_setopt($ch, CURLOPT_HTTPHEADER, array(
		'User: [info@moregreensolar.com]',
		'Api-Key: [x3L4d5VLpkoLKNAQq8cspniWcrhNXo]',
	));

	$result = curl_exec($ch);
	curl_close($ch);

	$response = json_decode($result, true);
	print_r($response);

	


?>