<?php
 $q=$_GET['q']; 
 //$q='d';
 $my_data=mysqli_real_escape_string($q);
 include "shreeLib/dbconn.php";
 
 $sql="SELECT DISTINCT `name` FROM tbl_employee WHERE `name` LIKE '%$my_data%'";
 $result = mysqli_query($con,$sql);
// echo  $sql;
 if($result)
 {
  while($row=mysqli_fetch_array($result))
  {
	echo $row['name']."\n";
  }
 }
?>