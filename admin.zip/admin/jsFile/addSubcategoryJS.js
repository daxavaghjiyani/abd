var modelType = "";
function performAction(){
        if (modelType === "add"){
          addSubcategory();
        } else if (modelType === "edit"){
          editSubcategory();
        } 
        else if (modelType === "delete"){
          delSubcategory();
        }      
}
function setDataForEdit(id){
        modelType = "edit";
        $("#modelTitle").text("Edit Sub category");
        $("#btn-add-subcategory").text("Update Sub category");
        $("#btn-add-subcategory").attr("name","edit-subcategory");
        $("#image-label").text("Image.  Please Upload Image If You Want to change.");
        $(".mandatory").css("display","none");

        //console.log($("#" + id).parents("tr:first").find("td:nth-child(1)").text());

        $("#subcategory_id").val("" + $("#" + id).parents("tr:first").find("td:nth-child(1)").text());
        $("#edit_subcategory_id").val("" + $("#" + id).parents("tr:first").find("td:nth-child(1)").text());
        $("#name").val("" + $("#" + id).parents("tr:first").find("td:nth-child(2)").text());
        $("#addcategory").hide();

        $.ajax({
        url:"phpFile/editSubcategoryPro.php",
        type:"POST",
        data:{
          id:$("#subcategory_id").val()
        },
        dataType:"html",
        success:function(result){
        console.log("test");
        $("#editcategory").html(result);

        }
        });


}
function readyForAdd1(){
        modelType = "add";
        $(".mandatory").css("display","block");
        $("#modelTitle").text("Add Sub category");
        $("#btn-add-subcategory").text("Add Sub category");
}
function removeRow(id){
        modelType = "delete";
        $("#subcategory_id").val("" + $("#" + id).parents("tr:first").find("td:nth-child(1)").text());
}
function delSubcategory(){
        $.ajax({
        url:"phpFile/delSubcategoryPro.php",
        type:"POST",
        data:{
          id:$("#subcategory_id").val()
        },
        dataType:"json",
        success:function(){
        alert("Sub category Deleted Successfully");
        $("#delete").trigger("click");
        window.location="subcategory.php";
        },
        fail:function(){
        alert("fail");
        }
        });
}
