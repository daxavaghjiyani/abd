var modelType = "";
function performAction(){
        if (modelType === "add"){
          addCategory();
        } else if (modelType === "edit"){
          editCategory();
        } 
        else if (modelType === "delete"){
          delCategory();
        }      
}
function setDataForEdit(id){
        modelType = "edit";
        $("#modelTitle").text("Edit Category");
        $("#btn-add-category").text("Update Category");
        $("#btn-add-category").attr("name","edit-category");
        $("#icon-label").text("Icon.  Please Upload Icon If You Want to change.");
        $(".mandatory").css("display","none");
        $("#category_id").val("" + $("#" + id).parents("tr:first").find("td:nth-child(1)").text());
        $("#edit_category_id").val("" + $("#" + id).parents("tr:first").find("td:nth-child(1)").text());
        $("#name").val("" + $("#" + id).parents("tr:first").find("td:nth-child(2)").text());
}
function readyForAdd1(){
        modelType = "add";
        $(".mandatory").css("display","block");
        $("#modelTitle").text("Add Category");
        $("#btn-add-category").text("Add Category");
}
function removeRow(id){
        modelType = "delete";
        $("#category_id").val("" + $("#" + id).parents("tr:first").find("td:nth-child(1)").text());
}
function delCategory(){
        $.ajax({
        url:"phpFile/delCategoryPro.php",
        type:"POST",
        data:{
          id:$("#category_id").val()
        },
        dataType:"json",
        success:function(){
        alert("Category Deleted Successfully");
        $("#delete").trigger("click");
        window.location="category.php";
        },
        fail:function(){
        alert("fail");
        }
        });
}
