
function adminLogin()
{
    if (this.uname.value !== "" && this.pwd.value !== "") {

        $.ajax({
            url: "phpFile/adminPro.php",
            type: "POST",
            data: {
                username: $("#uname").val(),
                password: $("#pwd").val()
            },
            dataType: "json",
            success: function(html) {
                if(html.status === true)    {
			 window.location="home.php";
			}
                else
                {
                    alert("Username or password does not match");
                    $('input[type=text], textarea').val('');
                    $('input[type=password], textarea').val('');
                }
            }
        });
    }
    else
    {
        alert("Please fill all fields first");
    }
}
function forgetPass()
{
    if (this.email_address.value !== "") {

        $.ajax({
            url: "phpFile/forgetPassPro.php",
            type: "POST",
            data: {
                email: $("#email_address").val()
            },
            dataType: "json",
            success: function(data) {
                if (data.status == true) {
                    alert("password sent to your registered email address");
                    $('input[type=email], textarea').val('');
                    $("#login").css('display', 'none');
                    window.location.reload(true);
                }
                else
                {
                    alert("Email Address not match with your registered email.");
                    $('input[type=email], textarea').val('');
                    $('input[type=password], textarea').val('');
                    window.location.reload(true);
                }
            }
        });
    }
    else
    {
        alert("Please fill all fields first");
    }
}
