var modelType = "";
function performAction(){
        if (modelType === "add"){
          addProduct();
        } else if (modelType === "edit"){
          editProduct();
        } 
        else if (modelType === "delete"){
          delProduct();
        }      
}
function setDataForEdit(id){
        modelType = "edit";
        $("#modelTitle").text("Edit Product");
        $("#btn-add-product").text("Update Product");
        $("#btn-add-product").attr("name","edit-product");
        $("#image-label").text("Images.  Please Upload Image If You Want to change.");
        $(".mandatory").css("display","none");
        $("#product_id").val("" + $("#" + id).parents("tr:first").find("td:nth-child(1)").text());
        $("#edit_product_id").val("" + $("#" + id).parents("tr:first").find("td:nth-child(1)").text());
        $("#name").val("" + $("#" + id).parents("tr:first").find("td:nth-child(2)").text());
}
function readyForAdd1(){
        modelType = "add";
        $(".mandatory").css("display","block");
        $("#modelTitle").text("Add Product");
        $("#btn-add-product").text("Add Product");
}
function removeRow(id){
        modelType = "delete";
        $("#product_id").val("" + $("#" + id).parents("tr:first").find("td:nth-child(1)").text());
}
function delProduct(){
        $.ajax({
        url:"phpFile/delProductPro.php",
        type:"POST",
        data:{
          id:$("#product_id").val()
        },
        dataType:"json",
        success:function(){
        alert("Product Deleted Successfully");
        $("#delete").trigger("click");
        window.location="product.php";
        },
        fail:function(){
        alert("fail");
        }
        });
}
