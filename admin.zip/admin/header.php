<?php 
    date_default_timezone_set('Asia/Kolkata');
?>
<!DOCTYPE html>
<html>
<head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Administrater Panel</title>

        <!--Morris Chart CSS -->
		    <link rel="stylesheet" href="assets/plugins/morris/morris.css">
<link href="assets/plugins/footable/css/footable.core.css" rel="stylesheet">
		<link href="assets/plugins/bootstrap-select/dist/css/bootstrap-select.min.css" rel="stylesheet" />
		<link href="assets/plugins/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css" rel="stylesheet">
        <link href="assets/plugins/clockpicker/dist/jquery-clockpicker.min.css" rel="stylesheet">
		
		<link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/core.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/components.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/icons.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/pages.css" rel="stylesheet" type="text/css" />
        <link href="assets/css/responsive.css" rel="stylesheet" type="text/css" />
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>

       <script src="assets/js/modernizr.min.js"></script>


    </head>
<?php
    $db_user="root";
    $db_password="";
    $db_host="localhost";
    $db_name="admin";
    $link=mysqli_connect($db_host,$db_user,$db_password,$db_name);
    if(!$link){
        echo 'can not connect to database '.  mysqli_error();
    }
    else {

    }
?>
   <?php 
if(isset($_GET['page']))
{
  $page = $_GET['page']; 
  ?>
  <script>
var page1='<?php echo $page; ?>';
console.log(page1);
function Load()
{

    $('li.footable-page > a').closest("li").removeClass("active");
    $('li.footable-page > a[data-page="' + page1 + '"]').parent().addClass("active");
    $('li.footable-page > a[data-page="' + page1 + '"]').trigger('click');
}
</script>

  <?php
}
?>
<body class="fixed-left" >

      <!--  <div class="animationload">
            <div class="loader"></div>
        </div>-->
        <div id="wrapper">
            <div class="topbar">
                <div class="topbar-left">
                    <div class="text-center">
                        <a href="home.php" class="logo"><span>Dashboard</span> <span class="grey"></span></a>
                    </div>
                </div>
                <div class="navbar navbar-default" role="navigation">
                    <div class="container">
                        <div class="">
                            <div class="pull-left">
                                <button class="button-menu-mobile open-left">
                                    <i class="ion-navicon"></i>
                                </button>
                                <span class="clearfix"></span>
                            </div>
                            <ul class="nav navbar-nav navbar-right pull-right">
                                <li class="dropdown">
                                <a href="logout.php"><i class="ti-power-off m-r-5"></i> Logout</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
<?php //include"popup.php"; ?>
<script>
			$(document).ready(function() {

				
               
                $('#datepicker').datepicker();
                $('#datepicker1').datepicker();
				$('#status_date').datepicker();
				$('.clockpicker').clockpicker({
                	donetext: 'Done'
                });
				
               
				
			});
		</script>	