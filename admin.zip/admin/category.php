<?php
session_start();
include'shreeLib/dbconn.php';
if(!isset($_SESSION['username']) && !isset($_SESSION['id'])  && !isset($_SESSION['type']))
{
  header("location:index.php");
}
?>
<?php include"header.php"; ?>
<!-- ========== Left Sidebar Start ========== -->
<?php include"sidebar.php"; ?>


<script src="jsFile/addCategoryJS.js"></script>
<style>
    .footable > tfoot .pagination1 {
  display: inline-block;
    padding-left: 0;
    margin: 20px 0;
    border-radius: 4px;
}
.pagination1 > li:first-child > a,
.pagination1 > li:first-child > span {
  border-bottom-left-radius: 3px;
  border-top-left-radius: 3px;
}
.pagination1 > li:last-child > a,
.pagination1 > li:last-child > span {
  border-bottom-right-radius: 3px;
  border-top-right-radius: 3px;
}
.pagination1 > li > a,
.pagination1 > li > span {
  color: #fff;
      position: relative;
    float: left;
    padding: 6px 12px;
    margin-left: -1px;
    line-height: 1.42857143;
    text-decoration: none;
    background-color: #fff;
    border: 1px solid #ddd;
}
.pagination1 > li > a:hover,
.pagination1 > li > span:hover,
.pagination1 > li > a:focus,
.pagination1 > li > span:focus {
  background-color: #e4e7ea;
}
.pagination-split1 li {
  margin-left: 5px;
  display: inline-block;
  float: left;
}
.pagination-split1 li:first-child {
  margin-left: 0;
}
.pagination-split1 li a {
  -moz-border-radius: 3px;
  -webkit-border-radius: 3px;
  border-radius: 3px;
}
.pagination1 > .active > a,
.pagination1 > .active > span,
.pagination1 > .active > a:hover,
.pagination1 > .active > span:hover,
.pagination1 > .active > a:focus,
.pagination1 > .active > span:focus {
  background-color: #d43b3e;
  border-color: #d43b3e;
}
.pager1 li > a,
.pager1 li > span {
  -moz-border-radius: 3px;
  -webkit-border-radius: 3px;
  border-radius: 3px;
  color: #636e7b;
}

</style>

<!-- ============================================================== -->
<!-- Start right Content here -->
<!-- ============================================================== -->
<div class="content-page">
    <!-- Start content -->
    <div class="content">
        <div class="container">

            <!-- Page-Title -->
            <div class="row">
                <div class="col-sm-12">

                    <ol class="breadcrumb">
                        <li>
                            <a href="home.php">Home</a>
                        </li>
                        <li class="active">
                            <a href="category.php">Categories</a>
                        </li>
                    </ol>
                </div>
            </div>            
            <div class="row">
                <div class="col-sm-12">
                    <div class="card-box">
                        <h4 class="m-t-0 header-title"><b>Categories</b></h4>
                        <p class="text-muted m-b-30 font-13">
  
                        </p>
          <div class="table-responsive" data-pattern="priority-columns">
                        <table   id="demo-foo-addrow"  class="table table-striped m-b-0 table-hover toggle-circle" data-page-size="25">
                            <thead>
                                <tr>
                                    <th  style="display:none;">Id</th>
                                    <th >Name</th>
                                    <th >Icon</th>
                                    <th >Created Date</th>   
                                    <th  class="min-width" >Action</th>
                                </tr>
                            </thead>
                            <div class="pad-btm form-inline">
                                <div class="row">
                                    <div class="col-sm-6 text-xs-center">
                                        <div class="form-group">

                                            <button class="btn btn-pink waves-effect waves-light" onclick="readyForAdd1();" data-toggle="modal" data-target="#con-close-modal">Add New Category</button>
                                          
                                          
                    
                    </div>
                                    </div>
                                    <div class="col-sm-6 text-xs-center text-right">
                                        <div class="form-group">
                                            <input id="demo-input-search2" type="text" placeholder="Search" class="form-control  input-sm" autocomplete="off">
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <tbody id="subcategory-data">
                                <?php
                                include"shreeLib/dbconn.php";
                $id = $_SESSION['id'];
                $user = $_SESSION['type'];
                                $offset = 0;
                            $page_result = 25; 
                            if(isset($_GET['pageno']))
                                {
                                 $page_value = $_GET['pageno'];
                                 if($page_value > 1)
                                 {  
                                  $offset = ($page_value - 1) * $page_result;
                                 }
                                }
                                else
                                {
                                        $page_value = 1;
                                 if($page_value >= 1)
                                 {  
                                  $offset = ($page_value - 1) * $page_result;
                                 }
                                }
                               
             
                 
                               $sql1="select * from category";
                               $result1=mysqli_query($con,$sql1);
                               $count=mysqli_num_rows($result1);
                               $query = "select * from category order by created_at desc limit $offset, $page_result";
                               $result = mysqli_query($con, $query);
                                ?>
                               <?php while ($row = mysqli_fetch_array($result)) { ?>
                                <tr>
                                    <td style="display:none;"><?php echo $row['id'] ?></td>
                                    <td><?php echo $row['name'] ?></td>
                                    <td style="display:none;"><?php echo $row['icon'] ?></td>
                                    <td><img src="assets/images/category/<?php echo $row['icon'] ?>" style="width:50px;height:50px;"></td>
                                    <td><?php if($row['created_at']!='0000-00-00'){ echo date('d-m-Y', strtotime($row['created_at']));}?></td>
                                    <td>
                                    <input type="hidden"  name="category_id" id="category_id">
                                    <a id='<?php echo $row['id']; ?>' onclick="removeRow(this.id);" data-toggle="modal" data-target="#custom-width-modal" title="Delete"> <i class="fa fa-trash-o"></i> </a>&nbsp;
                                    <a id='<?php echo $row['id']; ?>' onclick="setDataForEdit(this.id);" class='edit' data-toggle="modal" data-target="#con-close-modal" title="Edit Category"><i class="fa fa-edit"></i> </a>&nbsp;
                                    </td>
                                </tr>
<?php } ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td colspan="12">
                                        <div class="text-left">
                                           <ul class="pagination1 pagination-split1 m-t-30">

                                          <?php

 $pagecount = $count;
 $num = $pagecount / $page_result ;
if(!isset($_GET['pageno']))
$_GET['pageno']=1;
if($_GET['pageno']>1)
{
    echo "<li class='footable-page-arrow'><a href = 'category.php?pageno=".($_GET['pageno'] - 1)." '>‹</a></li>";
}

for($i = 1 ; $i <= ceil($num) ; $i++)
{
    
if(isset($_GET['pageno']) && $i==$_GET['pageno'])
{
        $active='active';
}
else
{
    $active='';
}

   echo "<li class='footable-page ".$active."' ><a  href = 'category.php?pageno=".$i."'>". $i ."</a></li>";
}
if($_GET['pageno'] != ceil($num) && ceil($num) !=0)
{
    echo "<li class='footable-page-arrow'><a  href = 'category.php?pageno=".($_GET['pageno'] + 1)." '>›</a></li>";
   
}
?>
</ul>
                                        </div>
                                    </td>
                                </tr>
                            </tfoot>
                        </table>
          </div>
        
                        <div id="con-close-modal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                            <div class="modal-dialog"> 
                                <div class="modal-content"> 
                                    <div class="modal-header"> 
                                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button> 
                                        <h4 class="modal-title" id="modelTitle">Add New Category</h4> 
                                    </div> 
                                    <form method="POST" enctype="multipart/form-data">
                                        <div class="modal-body"> 
                                            <div class="row"> 
                                                <div class="col-md-12">
                          <?php
                    include "shreeLib/formFields.php";
                    $dba=new formField();
                    ?>
                                                        
                            <div class="form-group"> 
                                <label for="field-1" class="control-label">Name</label>
                                <input type="text" class="form-control" name="name" id="name" placeholder="Enter Category Name">
                                <input type="hidden" class="form-control" name="created_user_id" id="created_user_id" value="<?php echo $_SESSION['id'];?>">
                                <input type="hidden" class="form-control" name="edit_category_id" id="edit_category_id" value=""> 
                            </div>
                            <div class="form-group"> 
                                <label for="field-1" class="control-label" id="icon-label">Icon</label>
                                <input type="file" class="form-control" name="icon" id="icon" placeholder="Upload Icon"> 
                            </div>
                            <div class="form-group" style="display:none;"> 
                                <label for="field-1" class="control-label">Date</label>
                                <input type="text" class="form-control" name="created_at"  id="datepicker" placeholder="dd-mm-yyyy"> 
                            </div>
                          
                                             
                                                </div> 


                                            </div> 
                                        </div> 

                                        <div class="modal-footer"> 
                                            <button type="button" class="btn btn-pink waves-effect" data-dismiss="modal" id="remove">Close</button> 
                                            <button type="submit" name="add-category" class="btn btn-pink waves-effect waves-light"  id="btn-add-category" >Add Category</button> 
                                        </div>
                                        </form> 
                                 
                                </div> 
                            </div>
                        </div>
                        
                        <div id="custom-width-modal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="custom-width-modalLabel" aria-hidden="true" style="display: none;">
                                        <div class="modal-dialog" style="width:30%;">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                 
                                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                                    <h4 class="modal-title" id="custom-width-modalLabel">Delete Category</h4>
                                                </div>
                                                <div class="modal-body">
                                                    <h4>Are you realy want to delete this Category?</h4>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-default waves-effect" data-dismiss="modal" id="delete">Close</button>
                                                    <button type="button" class="btn btn-primary waves-effect waves-light" onclick="delCategory();">Delete</button>
                                                </div>
                                            </div><!-- /.modal-content -->
                                        </div><!-- /.modal-dialog -->
                        </div><!-- /.modal -->
                    </div> <!-- container -->

                </div> <!-- content -->
<?php include"footer.php"; ?>
<?php
if(isset($_POST['add-category'])){
 
$name=$_POST['name'];
$icon=$_FILES['icon']['name'];
//echo $icon;
//return false;
$target_dir = "assets/images/category/";
$target_file = $target_dir . basename($_FILES["icon"]["name"]);
move_uploaded_file($_FILES["icon"]["tmp_name"], $target_file);
//return false;

    $query="INSERT INTO category (name, icon, created_at) VALUES ('".$name."' , '".$icon."','".date('Y-m-d')."')";
    //echo $query;
    //return false;
    mysqli_query($link,$query);
    ?>
    <script>
        alert('Category Added Successfully');
    </script>
<?php 

}

?>

<?php
if(isset($_POST['edit-category'])){
 
$name=$_POST['name'];
$id=$_POST['edit_category_id'];
if($_FILES["icon"]["name"])
{
$icon=$_FILES['icon']['name'];
//echo $icon;
//return false;
$target_dir = "assets/images/category/";
$target_file = $target_dir . basename($_FILES["icon"]["name"]);
move_uploaded_file($_FILES["icon"]["tmp_name"], $target_file);
//return false;

   // $query="INSERT INTO category (name, icon, created_at) VALUES ('".$name."' , '".$icon."','".date('Y-m-d')."')";
    $query = "UPDATE category SET name='".$name."' , icon='".$icon."' WHERE id='".$id."'";
    //echo $query;
    //return false;
    mysqli_query($link,$query);
    ?>
    <script>
        alert('Category Updated Successfully');
        window.location("category.php");
    </script>
<?php 

}


else
{
   $query = "UPDATE category SET name='".$name."' WHERE id='".$id."'";
    //echo $query;
    //return false;
    mysqli_query($link,$query);
?>
    <script>
        alert('Category Updated Successfully');
        window.location("category.php");
    </script>
<?php 
}
}
?>

<script>
      jQuery(document).ready(function() {

        
                // Date Picker
                jQuery('#datepicker').datepicker();
                jQuery('#datepicker1').datepicker();
        jQuery('#status_date').datepicker();
        $('.clockpicker').clockpicker({
                  donetext: 'Done'
                });
        $('#demo-foo-addrow1').footable();
               
        
      });



 jQuery(document).ready(function() {
            //var $table = $('#demo-foo-addrow1');
       // var $table1 = $('.convert');

     $('#demo-foo-addrow1').footable();
      $('.convert').footable();
        //$table1.bootstrapTable();
        
            
      
        });
 
    </script>
    <link rel="stylesheet" type="text/css" href="js/src/jquery.autocomplete.css">
    
    <script type="text/javascript" src="js/src/jquery.autocomplete.js"></script>
<script>
      $(document).ready(function (){
  
        
  
    $("#searchbyname").autocomplete("autocompletename1.php", {
  
      selectFirst: false


     
    });
  
  
});
</script>


                <script src="assets/plugins/magnific-popup/dist/jquery.magnific-popup.min.js"></script>
                </body>

               
                </html> 
