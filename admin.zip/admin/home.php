<?php
session_start();
date_default_timezone_set('Asia/Kolkata');

	/*$currentTime = time() + 25200;
	$expired = 3600;
	$_SESSION['timeout'] = $currentTime + $expired;
	if($currentTime > $_SESSION['timeout']){
		session_destroy();
		header("location:index.php");
	}*/
	
include'shreeLib/dbconn.php';

if(!isset($_SESSION['username']) && !isset($_SESSION['id']) && !isset($_SESSION['type']))
{
	header("location:index.php");
}

	

?>
<?php include"header.php"; ?>
<!-- ========== Left Sidebar Start ========== -->
<?php include"sidebar.php"; ?>


<script src="jsFile/addCategoryJS.js"></script>
<?php

$id = $_SESSION['id'];
$user = $_SESSION['type'];
if($user=="Admin")
{
$sql_cat = "SELECT COUNT(*) as num FROM category";
	$total_cat = mysqli_query($con, $sql_cat);
	$total_cat = mysqli_fetch_array($total_cat);
	$total_cat = $total_cat['num'];
	
$sql_subcat = "SELECT COUNT(*) as num  from subcategory";
	$total_subcat = mysqli_query($con, $sql_subcat);
	$total_subcat = mysqli_fetch_array($total_subcat);
	$total_subcat = $total_subcat['num'];

$sql_pro = "SELECT COUNT(*) as num FROM product";
	$total_pro = mysqli_query($con, $sql_pro);
	$total_pro = mysqli_fetch_array($total_pro );
	$total_pro  = $total_pro ['num'];
$sql_salaryslip = "SELECT COUNT(*) as num  from tbl_employee e inner join  salaryslip s on e.id = s.employee_id";
	$total_salaryslip = mysqli_query($con, $sql_salaryslip );
	$total_salaryslip = mysqli_fetch_array($total_salaryslip);
	$total_salaryslip = $total_salaryslip['num'];
}

?>
<div class="content-page">
                <!-- Start content -->
                <div class="content">
                    <div class="container">
                        <!-- Page-Title -->
                        <div class="row">
                            <div class="col-sm-12">
                                <h4 class="page-title bg-white">Welcome to Administrator Panel </h4>
                                <p class="text-muted page-title-alt"></p>
                            </div>
                        </div>
                        
                        <div class="row home-icon">
                            <div class="col-lg-3 col-sm-6">

							<a href="category.php">
                                <div class="widget-panel widget-style-2 bg-white">
                                    <i class="md icon-people text-pink"></i>
                                    <h2 class="m-0 text-dark counter font-600"><?php echo $total_cat;?></h2>
                                    <div class="text-muted m-t-5">Categories</div>
                                </div>
							</a>
                            </div>
                            <div class="col-lg-3 col-sm-6">

							<a href="subcategory.php">
                                <div class="widget-panel widget-style-2 bg-white">
                                    <i class="md icon-note text-pink"></i>
                                    <h2 class="m-0 text-dark counter font-600"><?php echo $total_subcat;?></h2>
                                    <div class="text-muted m-t-5">Subcategories</div>
                                </div>
							</a>
                            </div>
                            
                             <div class="col-lg-3 col-sm-6">

							<a href="product.php">
                                <div class="widget-panel widget-style-2 bg-white">
                                    <i class="md icon-docs text-pink"></i>
                                    <h2 class="m-0 text-dark counter font-600"><?php echo $total_pro;?></h2>
                                    <div class="text-muted m-t-5">Products</div>
                                </div>
							</a>
                            </div>
                            <div class="col-lg-3 col-sm-6">

							<a href="salaryslip_listing.php">
                                <div class="widget-panel widget-style-2 bg-white">
                                    <i class="md icon-docs text-pink"></i>
                                    <h2 class="m-0 text-dark counter font-600"><?php echo $total_salaryslip;?></h2>
                                    <div class="text-muted m-t-5">Products</div>
                                </div>
							</a>
                            </div>
</div>
</div> <!-- content -->
</div>
<?php include"footer.php"; ?>
<script src="assets/plugins/magnific-popup/dist/jquery.magnific-popup.min.js"></script>
</body>
</html>
